async function sendMessage() {
  const input = document.getElementById("user-input");
  const chatBox = document.getElementById("chat-box");
  const userText = input.value.trim();
  if (!userText) return;

  // Show user message
  chatBox.innerHTML += `<div><strong>You:</strong> ${userText}</div>`;
  input.value = "";
  chatBox.scrollTop = chatBox.scrollHeight;

  // Call OpenAI API (replace YOUR_API_KEY)
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer YOUR_API_KEY"
    },
    body: JSON.stringify({
      model: "gpt-4",
      messages: [{ role: "user", content: userText }]
    })
  });

  const data = await response.json();
  const botReply = data.choices?.[0]?.message?.content || "Sorry, no response.";

  chatBox.innerHTML += `<div><strong>GPT:</strong> ${botReply}</div>`;
  chatBox.scrollTop = chatBox.scrollHeight;
}
